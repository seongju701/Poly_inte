export default async function () {
  await this.clickByTestId('summarizedOrderImage', 'div');
    await this.containText('주문을 시작해주세요.');  
}
