export default async function (tag, testId) {
  await this.clickByTestId(testId, tag);
}
