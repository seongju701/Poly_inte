export default async function (tag, testId, position, index) {
  await this.client.waitUntil(async () => {
    const text = await this.client.$(`${tag}[data-testid=${testId}]`).getText();
    const word = text.split(' ')[position - 1];
    const number = parseInt(word.replace(/,/g, ''), 10);

    this.memory[index - 1] = number;

    return true;
  }, 5000);
}
