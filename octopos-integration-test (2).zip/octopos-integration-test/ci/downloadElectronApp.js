// const Octokit = require('@octokit/rest');
const AWS = require('aws-sdk');
const _ = require('lodash');
const download = require('download');
const fs = require('fs');
const path = require('path');
const extract = require('extract-zip');

const distFolder = path.join(__dirname, '../dist/');
const zipPath = path.join(distFolder, 'electronApp.zip');
const appPath = path.join(distFolder, '/electronApp/');

const getCurrentReleaseVersion = async () => {
  const s3 = new AWS.S3({
    accessKeyId: process.env.AWS_ACCESS_KEY_ID,
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
  });

  const bucket = `release-pos-client-${process.env.BUILD_TARGET}`;
  const params = {
    Bucket: bucket, 
    Key: "RELEASES"
  };
  return new Promise((resolve, reject) => {
    s3.getObject(params, (err, data) => {
      if (err) {
        reject(err);
      }
      try {
        const version = data.Body.toString().split(/\s/)[2].match(/\d+\.\d+\.\d+/)[0];
        resolve(version);
      } catch (error) {
        reject(error);
      }
    });
  })
};

const getZipUrl = async () => {
  const version = await getCurrentReleaseVersion();
  const downloadUrl = `https://release-pos-client-${process.env.BUILD_TARGET}.s3.ap-northeast-2.amazonaws.com/`;
  let downloadZipFile ;
  switch(process.env.BUILD_TARGET) {
    case 'develop':
      downloadZipFile = `polyDevelop-${version}-ia32-win.zip`;
      break;
    case 'rc':
      downloadZipFile = `polyRC-${version}-ia32-win.zip`;
      break;
    case 'staging':
      downloadZipFile = `polyStaging-${version}-ia32-win.zip`;
      break;
    default :
      downloadZipFile = `poly-${version}-ia32-win.zip`;
  } 
  return downloadUrl.concat(downloadZipFile)
};

const downloadZipFile = async (url) => {
  if (!fs.existsSync(distFolder)) {
    fs.mkdirSync(distFolder);
  }
  const data = await download(url);
  fs.writeFileSync(zipPath, data);
}

const unizip = () => {
  return new Promise(function(resolve, reject) {
    extract(zipPath, { dir: appPath }, function (err) {
      if (err) {
        reject();
      } else {
        resolve();
      }
    })
  })
}

const downloadElectronApp = async () => {
  const zipUrl = await getZipUrl();
  console.log(zipUrl);
  await downloadZipFile(zipUrl);
  await unizip();
};

downloadElectronApp();
