export default async function (url) {
  await this.goToPageByUrl(url);
}
