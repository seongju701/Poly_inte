export default async function (css) {
  await this.waitElements(css, 1);
}
