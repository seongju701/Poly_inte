export default async function (testId) {
  await this.clickByTestId(testId, 'input');
}
