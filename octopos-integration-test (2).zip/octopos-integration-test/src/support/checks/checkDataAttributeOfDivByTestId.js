export default async function (testId, attributeName, value) {
  await this.client.waitUntil(async () => {
    const data = await this.client.$(`div[data-testid=${testId}]`).getAttribute(`data-${attributeName}`);
    return value === data;
  }, 8000);
}
