export default async function (pro) {
  await this.receivePrice(pro);
}
