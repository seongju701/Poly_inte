export default async function () {
  await this.clickByTestId('profileButton', 'div');
    //await this.containText('로그 아웃');
}
