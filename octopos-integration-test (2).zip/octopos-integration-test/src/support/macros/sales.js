export default async function () {
  await this.clickByTestId('homeMenuButton-orderHistory', 'div');
  await this.containText('영업관리');  
}
