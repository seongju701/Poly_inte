import { Before, BeforeAll, setWorldConstructor } from 'cucumber';
import BrowserWorld from '../worlds/browserWorld';

BeforeAll((done) => {
  setWorldConstructor(BrowserWorld);
  done();
});

Before({ timeout: 30 * 1000 }, function () {
  return this.start();
});
