export default async function (text, pin) {
  const condition = await this.containTextInBody(text);
  if (condition) {
    await this.pinLogin(pin);
  }
}
