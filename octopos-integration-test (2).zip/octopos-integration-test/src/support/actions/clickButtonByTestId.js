import { TEST_TARGET } from '../constants';

export default async function (testId) {
  await this.clickByTestId(testId, TEST_TARGET === 'electron' ? 'div' : 'button');
}
