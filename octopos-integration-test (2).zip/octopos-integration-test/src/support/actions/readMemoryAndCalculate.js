import calculator from '../utils/calculator';

export default async function (source, number, operator, destination) {
  this.memory[destination - 1] = calculator(this.memory[source - 1], number, operator);
}
