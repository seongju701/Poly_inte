export default async function (testId, displayText) {
  await this.client.waitUntil(async () => {
    const text = await this.client.$(`div[data-testid=${testId}]`).getText();
    return displayText === text;
  }, 2000);
}
