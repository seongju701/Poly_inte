import { expect } from 'chai';

export default async function (source, number) {
  expect(this.memory[source - 1]).to.equal(number);
}
