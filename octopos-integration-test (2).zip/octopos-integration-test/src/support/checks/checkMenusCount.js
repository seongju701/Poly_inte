export default async function (count) {
  const css = 'div[data-testid=MenusFlatList] div[role=button]';
  await this.waitElements(css, count);
}
