let common = './src ';
common += '--require-module @babel/register ';
common += '-r ./src/initialize.js';

module.exports = {
  default: common,
};
