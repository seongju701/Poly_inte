/* eslint-disable no-nested-ternary */
export default function (left, right, operator) {
  return operator === '+' ? left + right
    : operator === '-' ? left - right
      : operator === '*' ? left * right
        : operator === '/' ? left / right : undefined;
}
