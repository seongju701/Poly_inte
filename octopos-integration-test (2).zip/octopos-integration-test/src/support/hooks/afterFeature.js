import { After, setDefaultTimeout } from 'cucumber';

setDefaultTimeout(60 * 1000);

After(function () {
  return this.quit();
});
