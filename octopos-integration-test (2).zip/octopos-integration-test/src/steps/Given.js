import { Given } from 'cucumber';

import checkDisplayString from '../support/checks/checkDisplayString';
import checkIfExistsByTestId from '../support/checks/checkIfExistsByTestId';
import goToPageByUrl from '../support/actions/gotoPageByurl';
import goToInitPage from '../support/actions/gotoInitPage';
import conditionalPinLogin from '../support/macros/conditionalPinLogin';
import conditionalRegisterPos from '../support/macros/conditionalRegisterPos';

Given('화면에 {string} 있을시에', checkDisplayString);
Given('{string} 화면에 있습니다.', checkIfExistsByTestId);
Given('{string} 이동', goToPageByUrl);
Given('초기화면으로 이동', goToInitPage);

Given('화면에 {string} 있으면 PIN LOGIN {string}', conditionalPinLogin);
Given('화면에 {string} 있으면 POS 등록 {string}', conditionalRegisterPos);
