
export default async function (inputField) {
  await this.focusByTestId(inputField, 'input');
}
