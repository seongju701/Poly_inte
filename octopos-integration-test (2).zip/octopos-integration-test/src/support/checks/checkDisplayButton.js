import { expect } from 'chai';

export default async function (testId) {
  expect(await this.findButtonByTestId(testId)).to.be.true;
}
