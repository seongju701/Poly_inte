import { readFileSync } from 'fs';
import { expect } from 'chai';
const printLogFile = './printerLog.txt';

export default function (text) {
  const printedContext = readFileSync(printLogFile, 'utf8').toString();
  console.log(printedContext);
  console.log(printedContext.indexOf(text)!==-1);
  expect(printedContext.indexOf(text) !== -1).to.be.true; 
}
