import { expect } from 'chai';


export default async function (testId) {
  const page = await this.findByTestId(testId, 'div');
  await expect(page).to.be;
}
