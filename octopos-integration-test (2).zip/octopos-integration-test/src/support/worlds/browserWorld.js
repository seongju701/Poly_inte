/* eslint-disable no-await-in-loop */
import { Application } from 'spectron';
import { remote } from 'webdriverio';

// import { setTimeout } from 'core-js';
import { API_HOST, TEST_TARGET, ELECTRON_APP_PATH } from '../constants';

export default class BrowserWorld {
  constructor() {
    this.memory = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0];

    if (TEST_TARGET === 'electron') {
      this.app = new Application({
        path: ELECTRON_APP_PATH,
      });
    }
  }

  async start() {
    if (TEST_TARGET === 'electron') {
      await this.app.start();
      this.client = this.app.client;
      await this._setMainWindow();
    } else if (TEST_TARGET === 'web') {
      this.client = await remote({
        logLevel: 'error',
        capabilities: {
          browserName: 'chrome',
        },
      });
      await this.client.url(API_HOST);
    }
  }

  async _setMainWindow() {
    const windowsCount = await this.client.getWindowCount();

    for (let i = 0; i < windowsCount; i += 1) {
      // eslint-disable-next-line no-await-in-loop
      await this.client.windowByIndex(i);

      try {
        // eslint-disable-next-line no-await-in-loop
        const body = await this.client.$('body').getText();
        if (body.match(/Intro/)) {
          break;
        }
      // eslint-disable-next-line no-empty
      } catch (error) {}
    }
  }

  async quit() {
    if (TEST_TARGET === 'web') {
      await this.client.closeWindow();
    } else {
      await this.app.stop();
    }
  }

  async goToPageByUrl(url) {
    await this.client.url(API_HOST + url);
  }

  findByTestId(testId, attr) {
    return this.client.waitUntil(() => this.client.$(`${attr}[data-testid=${testId}]`), 2000);
  }

  findButtonByTestId(testId) {
    return this.client.waitUntil(() => this.client.$(`div[data-testid=${testId}]`), 1000);
  }

  async clickByTestId(testId, attr) {
    await this.findByTestId(testId, attr);
    this._click(`${attr}[data-testid=${testId}]`);
  }

  async focusByTestId(testId, attr) {
    await this.findByTestId(testId, attr);
    this._click(`${attr}[data-testid=${testId}]`);
  }

  async typeInputByTestId(testId, text) {
    await this.findByTestId('input', testId);
    this._writeText(`input[data-testid=${testId}]`, text);
  }

  async toggleLabelByTestId(testId) {
    await this.findByTestId('label', testId);
    await this._toggle(`label[data-testid=${testId}]`);
  }

  async waitElements(css, count) {
    await this.client.waitUntil(async () => {
      const elements = await this.client.$$(css);
      return elements.length === count;
    }, 2000);
  }

  async containText(text, css = 'body') {
    await this.client.waitUntil(async () => {
      const regexp = new RegExp(text);
      let textInElement;

      if (TEST_TARGET === 'electron') {
        textInElement = await this.client.$(css).getText();
      }
      if (TEST_TARGET === 'web') {
        textInElement = await this._getText(css);
      }

      return textInElement.match(regexp);
    }, 5000);
  }

  async _click(css) {
    if (TEST_TARGET === 'electron') {
      return this.client.$(css).click();
    }
    const element = await this.getElement(css);
    return element.click();
  }

  async _getText(css) {
    const element = await this.getElement(css);
    return element.getText();
  }

  async _writeText(css, text) {
    const element = await this.getElement(css);
    text = element.setValue(text);
    return text;
  }

  async _toggle(css) {
    const element = await this.getElement(css);
    // const value = !element.checked;
    // element.checked = value;
    // return value;
    await element.click();
  }

  async getElement(css) {
    if (TEST_TARGET === 'electron') {
      return this.client.$(css);
    } if (TEST_TARGET === 'web') {
      // eslint-disable-next-line no-return-await
      return await this.client.$(css);
    }
    return undefined;
  }

  async getText(tag, testId) {
    return this.client.$(`${tag}[data-testid=${testId}]`).getText();
  }

  async checkText(tag, testId, text, timeout = 2000) {
    return this.client.waitUntil(async () => {
      const displayedText = await this.client.$(`${tag}[data-testid=${testId}]`).getText();
      return text === displayedText;
    }, timeout);
  }

  async getAttribute(tag, testId, attributeName) {
    return this.client.$(`${tag}[data-testid=${testId}]`).getAttribute(attributeName);
  }

  async containTextInBody(text) {
    const regexp = new RegExp(text);
    const textInElement = await this.client.$('body').getText();
    const result = textInElement.match(regexp);
    return result !== null;
    // return textInElement.match(regexp)[0] === text;
  }

  // for POS 
  // MACRO DEFINITIONS

  async pinLogin(pin) {
    const len = pin.length;

    for (let i = 0; i < len; i += 1) {
      await this.clickByTestId(`padButton-${pin[i]}`, 'div');

      if (i === len - 1) return;
      await this.checkText('div', `textNumber-${i}`, pin[i]);
    }
    await this.containText('오늘의 매출');
  }

  async registerPos(registerNumber) {
    const numbers = registerNumber.replace(/-/gi, '');
    const len = numbers.length;
    console.log(len);
    for (let i = 0; i < len; i += 1) {
      await this.clickByTestId(`padButton-${numbers[i]}`, 'div');
      await this.checkText('div', `textNumber-${i}`, numbers[i]);
    }
    await this.clickByTestId('registerButton', 'div');
    await this.containText('로그인');
  }

  async cashOrder(price) {
    await this.clickByTestId('mainActionButton-6', 'div');
    await this.clickByTestId('cashPayment-button-right-0', 'div');
    await this.checkText('div', `orderSummaryAmountToReceive-subTitle`, price);
    await this.containText('주문을 시작해주세요.');  
  }  

  async cardOrder(price) {
    await this.clickByTestId('mainActionButton-7', 'div');
    await this.clickByTestId('cardPayment-button-right-0', 'div');
    await this.checkText('div', `orderSummaryAmountToReceive-subTitle`, price);
    await this.containText('주문을 시작해주세요.');  
  }
  
  async itmeListOne(pro) {
    await this.checkText('div', `orderItemCell-0-title`, pro);  
  }  

  async receivePrice(pro) {
    await this.checkText('div', `orderSummaryAmountToReceive-subTitle`, pro);  
  }  

}
