import { TEST_TARGET } from '../constants';

export default async function () {
  if (TEST_TARGET === 'electron') {
    const ElementFound = await this.findByTestId('Intro', 'div');
    if (ElementFound.status !== 0) {
      await this.clickByTestId('logoutButton', 'div');
    }
  }
}
