export default async function (testId) {
  await this.client.waitUntil(async () => {
    const input = await this.findByTestId(testId, 'input');
    const value = await input.getValue();

    return value.length > 0;
  }, 2000);
}
