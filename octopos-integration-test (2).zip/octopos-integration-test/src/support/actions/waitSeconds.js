const sleep = m => new Promise(r => setTimeout(r, m));

export default async function (msec) {
  await sleep(msec);
}
