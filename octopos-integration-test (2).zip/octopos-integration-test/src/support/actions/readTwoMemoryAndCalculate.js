/* eslint-disable max-len */
import calculator from '../utils/calculator';

export default async function (left, right, operator, destination) {
  this.memory[destination - 1] = calculator(this.memory[left - 1], this.memory[right - 1], operator);
}
