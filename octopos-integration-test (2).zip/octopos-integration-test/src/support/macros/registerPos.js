export default async function (registerNumber) {
  await this.registerPos(registerNumber);
}
