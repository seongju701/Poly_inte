export default async function (testId, value) {
  // await this.client.$(`button[data-testid=${testId}] span`).setValue(value);
  // await this.client.$(`button[data-testid=${testId}]`).click();
  // const a = await this.client.$(`iframe #document html body div div div div div`).getAttribute('data-testid');
  // const a = await this.client.$("iframe");
  const a = await this.client.$('div[data-testid=reportHeader]');
  console.log('a = ', a);
}
