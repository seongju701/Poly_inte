import { POS_AUTH_CODE } from '../constants';

export default async function (text, registerNumber) {
  const authCode = registerNumber.length > 0 ? registerNumber : POS_AUTH_CODE;
  const condition = await this.containTextInBody(text);
  if (condition) {
    await this.registerPos(authCode);
  }
}
