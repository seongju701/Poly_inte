export default async function (pin) {
  await this.pinLogin(pin);
}
