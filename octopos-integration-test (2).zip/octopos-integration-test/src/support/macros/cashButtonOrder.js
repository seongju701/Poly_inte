export default async function (price) {
  await this.cashOrder(price);
}
