export default async function (testId, text) {
  await this.typeInputByTestId(testId, text);
}
