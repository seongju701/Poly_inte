export default async function () {
  await this.clickByTestId('IconButtonHome', 'div');
  await this.containText('오늘의 매출');  
}
