export default async function (testId) {
  await this.toggleLabelByTestId(testId);
}
