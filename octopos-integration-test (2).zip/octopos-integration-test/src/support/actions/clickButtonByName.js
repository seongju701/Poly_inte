export default async function () {
    console.log("아자아자");
  }
  