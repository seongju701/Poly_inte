export default async function (price) {
  await this.cardOrder(price);
}
