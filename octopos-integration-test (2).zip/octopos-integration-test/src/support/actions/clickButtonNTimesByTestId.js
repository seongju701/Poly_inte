import * as _ from 'lodash';

export default async function (testId, count) {
  _.times(count, async () => {
    await this.clickButtonByTestId(testId);
  });
}
