export default async function (tag, testId, displayText) {
  await this.client.waitUntil(async () => {
    const text = await this.client.$(`${tag}[data-testid=${testId}]`).getText();
    return displayText === text;
  }, 15000);
}
