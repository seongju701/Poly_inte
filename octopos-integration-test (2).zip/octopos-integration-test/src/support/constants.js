require('dotenv').config();

module.exports = {
  API_HOST: process.env.API_HOST,
  TEST_TARGET: process.env.TEST_TARGET || 'electron',
  ELECTRON_APP_PATH: process.env.ELECTRON_APP_PATH,
  POS_AUTH_CODE: process.env.POS_AUTH_CODE,
};
