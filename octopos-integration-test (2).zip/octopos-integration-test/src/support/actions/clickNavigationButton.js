
export default async function (button) {
  const testId = `Navigation${button}`;
  await this.clickButtonByTestId(testId, 'div');
}
