//const sleep = m => new Promise(r => setTimeout(r, m));

export default async function (displayText) {
  //await sleep(3000);
  await this.containText(displayText);
  //await sleep(3000);
}
