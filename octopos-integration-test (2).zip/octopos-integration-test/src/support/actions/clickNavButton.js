export default async function () {
  await this.clickByTestId('navSlideBar', 'a');
}
