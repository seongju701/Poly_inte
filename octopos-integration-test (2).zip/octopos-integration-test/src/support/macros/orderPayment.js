export default async function () {
  await this.clickByTestId('homeMenuButton-order', 'div');
    await this.containText('주문을 시작해주세요.');  
}
